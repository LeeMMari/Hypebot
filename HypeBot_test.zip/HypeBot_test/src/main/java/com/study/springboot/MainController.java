package com.study.springboot;

import java.io.IOException;
import java.util.List;

import org.apache.el.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {

	// 로그인 페이지 진입용 컨드롤러
	@GetMapping("/login")
	public String login() {
		System.out.println("로그인 페이지 진입");
		return "login";
	}
	
	
	// 회원가입 페이지 진입용 컨트롤러
	@GetMapping("/signup")
	public String signup() {
		System.out.println("회원가입 페이지 진입");
		return "signup";
	}
	
	
	@Autowired
	UserService userService;
	
	// 함수 호출
	Functions functions = new Functions();
	
	
	// 로그인 시 csv파일을 ajax로 변환해 /users로 보낸 후
	// login.jsp에 스크립트 단에서 /users로 간 데이터를 읽어서 대조하기위한 컨트롤러
	@GetMapping("/users")
	@ResponseBody
	public String ajaxUsers() {
		// 만든 함수인 userList 가 null 일때
		List<User> userList = null;
		
		try {
			userList = functions.getUserListFromCSV();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// java -> JSON 객체로 변환
		ObjectMapper mapper = new ObjectMapper();
		String jsonResult = "";
		
		try {
			jsonResult = mapper.writeValueAsString(userList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		return jsonResult;
	}
	
	
	// 로그인 처리용 컨트롤러
	@PostMapping("/login")
	public String Login(@RequestParam("id") String id,
						@RequestParam("password") String password,
						HttpServletRequest req) throws IOException, ParseException {
		
		// 세션 선언
		HttpSession session = req.getSession();
		
		List<User> userList = functions.getUserListFromCSV();
				for (User user : userList) {
			if (user.getId().equals(id) && user.getPassword().equals(password)) {	// 만약 id, password가 일치한다면
				
				// 세션에 모든 정보 저장
				session.setAttribute("id", id);
				session.setAttribute("password", password);
				session.setAttribute("age", user.getAge());
				session.setAttribute("preference", user.getPreference());
				session.setAttribute("rank", user.getRank());
				session.setAttribute("name", user.getName());
				System.out.println("로그인 성공");	 	// 동작 확인용
				
				// 로그인 잘 됐는지 확인용으로 ?success=true 넣음
				return "redirect:/MainPage?success=true";
			}
			System.out.println("로그인 실패");
		}
		// 실패 시 다시 로그인 페이지로
		return "redirect:/login?error=true";
	}
	
	
	// 메인 페이지 컨트롤러
	@GetMapping("/MainPage")
	public String MainPage(HttpServletRequest req
							) throws IOException, ParseException {
		
		HttpSession session = req.getSession();
		
		// 세션에서 계정 정보를 읽어옴
    	String id = (String) session.getAttribute("id");
    	Integer age = (Integer) session.getAttribute("age");
    	String preference = (String) session.getAttribute("preference");
    	Integer rank = (Integer) session.getAttribute("rank");
    	String name = (String) session.getAttribute("name");
        System.out.println("메인 페이지 진입");
        System.out.println("id : " + id);
        System.out.println("age : " + age);
        System.out.println("preference : " + preference);
        System.out.println("rank : " + rank);
        System.out.println("name : " + name);
		
		return "MainPage";
	}
	
	
	// 회원가입 처리용 컨트롤러
	// @RequestParam("id")를 해놓은 이유는 submit 할때 값을 받기 위함
	@PostMapping("/signup")
	public String signup(@RequestParam("id") String id,
						 @RequestParam("password") String password,
						 @RequestParam("age") int age,
						 @RequestParam("preference") String preference,
						 @RequestParam("name") String name
						 ) {
		// 동작 확인용 메시지
		System.out.println("회원가입 처리 완료");
		
		// rank는 따로 입력사항 없기 때문에 1로 넣음
		User user = new User(id, password, age, preference, 1, name);
		userService.save(user);
		
		// 세이브 성공시 메인페이지 이동
		return "redirect:/signupSuccess";
	}
	
	
	// 회원가입 완료 페이지 컨트롤러
	@GetMapping("/signupSuccess")
	public String signupSuccess() {
		System.out.println("회원가입 완료 페이지 진입");
		return "signupSuccess";
	}
	
	
	// 아이디 찾기 페이지 컨트롤러
	@GetMapping("/Idsuch")
	public String Idsuch() {
		System.out.println("아이디 찾기 진입");
		return "Idsuch";
	}
	
	
	// User.csv에서 이름 대조해 아이디 찾아주는 컨트롤러
	@GetMapping("/findId")
	@ResponseBody
	public String findId(@RequestParam("name") String name) throws IOException {
		
		List<User> userList = functions.getUserListFromCSV();
		for (User user : userList) {
			if (user.getName().equals(name)) {
				return "회원님의 아이디는 " + user.getId() + " 입니다.";
			}
		}
		return "일치하는 아이디가 없습니다.";
	}
	
	
	
	
	
}
