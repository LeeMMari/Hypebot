package com.study.springboot;

import java.io.IOException;
import java.io.RandomAccessFile;

import com.study.springboot.User;
import com.study.springboot.UserService;

import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.stereotype.Service;

// 유저 정보를 입력받았을 때, csv 파일로 저장하는 클래스

// 일해라! 라는 의미의 서비스 컨트롤러 등록
@Service	
public class UserServiceImpl implements UserService{

	// save 함수(회원가입 받기용)
	@Override
	public void save(User user) {
		// 예외가 많이 발생해, 그걸 해결하기 위해 함수를 try-catch 안에 만든다.
			// RandomAccessFile : file 읽어오는 메소드
		try (RandomAccessFile file = new RandomAccessFile("D:\\LeeSeonAh\\JAVA\\stsworkspace\\HypeBot_test\\src\\main\\resources\\metadata\\User.csv", "rw")) {
			long fileLength = file.length();
			file.seek(fileLength); // 파일 끝으로 이동 앞에 내용 덮어쓰기 방지
			file.writeBytes(user.getId() + "," + user.getPassword() + "," + user.getAge() + "," + user.getPreference() + "," + user.getRank() + "," + user.getName() + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
