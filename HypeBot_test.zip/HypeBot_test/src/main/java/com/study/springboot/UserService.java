package com.study.springboot;

import com.study.springboot.User;

// 유저 정보 관리용 인터페이스
public interface UserService {

	void save(User user);
	
}
