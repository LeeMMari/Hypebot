package com.study.springboot;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;


import org.springframework.core.io.ClassPathResource;

public class Functions {

	// 함수 리스트 생성
	public Functions() {
		List<User> userList;
		
		try {
						// 이름은 내가 마음대로 생성
			userList = getUserListFromCSV();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	// 유저정보 csv 읽어오는 메소드
	List<User> getUserListFromCSV() throws IOException {
		List<User> userList = new ArrayList<>();
		
		// 경로 설정
		// 경로 찾는 메소드
		ClassPathResource resource = new ClassPathResource("metadata/User.csv");
		
		// 메모리 효율성을 위한 BufferedReader
		BufferedReader reader = new BufferedReader(new FileReader(resource.getFile()));
		
		// 첫 번째 라인은 헤더
		String line = reader.readLine();
		
		while ((line = reader.readLine()) != null) { // 더 이상 읽을 수 없는 라인이 생길 때까지
			// 필드라는 리스트로 하나씩 저장, ","를 기준으로 데이터 읽어옴
			String[] fields = line.split(",");
			
			String id = fields[0];	// 첫 번째 id
			String password = fields[1]; // 두 번째 password
			int age = Integer.parseInt(fields[2]); // 세 번째 나이
			String preference = fields[3]; // 네 번째 취향
			int rank = Integer.parseInt(fields[4]); // 다섯 번째 등급
			String name = fields[5]; // 이름
			
			// user 객체에 담기
			User user = new User(id, password, age, preference, rank, name);
			
			// 추가
			userList.add(user);
		}
		
		reader.close();
		
		return userList;
	}
	
}
